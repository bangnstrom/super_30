package minimumsortarr;

import java.util.Comparator;

public class namecomparator implements Comparator<phone> {

	public static void main(String[] args) {
		
	}

	@Override
	public int compare(phone o1, phone o2) {
		return o1.phoneModel.compareTo(o2.phoneModel);
	}

}
