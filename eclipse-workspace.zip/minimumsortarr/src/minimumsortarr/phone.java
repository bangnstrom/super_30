package minimumsortarr;

public class phone implements Comparable<phone> {
	
	String phoneModel;
	int PhonePrice;

	@Override
	public String toString() {
		return "phone [phoneModel=" + phoneModel + ", PhonePrice=" + PhonePrice + "]";
	}

	public String getPhoneModel() {
		return phoneModel;
	}

	public void setPhoneModel(String phoneModel) {
		this.phoneModel = phoneModel;
	}

	public int getPhonePrice() {
		return PhonePrice;
	}

	public void setPhonePrice(int phonePrice) {
		PhonePrice = phonePrice;
	}

	public phone() {
		super();
		// TODO Auto-generated constructor stub
	}

	public phone(String phoneModel, int phonePrice) {
		super();
		this.phoneModel = phoneModel;
		PhonePrice = phonePrice;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public int compareTo(phone p2) {
		// TODO Auto-generated method stub
		
		return  this.PhonePrice - p2.PhonePrice;
	}

}
