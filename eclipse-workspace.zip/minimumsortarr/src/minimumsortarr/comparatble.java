package minimumsortarr;
import java.util.ArrayList;
import java.util.Collections;

public class comparatble {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Integer> a = new ArrayList<>();
		ArrayList<phone> phoneList = new ArrayList<>();
		
		
		phoneList.add(new phone("Samsungs24",45000));
		phoneList.add(new phone("Iphone15",120000));
		phoneList.add(new phone("Redmi",20000));
		phoneList.add(new phone("Motorola",17000));
		phoneList.add(new phone("Vivo",13000));
		
		a.add(10);
		a.add(2);
		a.add(7);
		a.add(4);
		a.add(3);
		a.add(12);
		a.add(7);
		a.add(1);
		System.out.println(a);
		Collections.sort(a);
		System.out.println(a);
		Collections.sort(phoneList);
		System.out.println(phoneList);
		Collections.sort(phoneList,new priceComparator());
		System.out.println(phoneList);
		Collections.sort(phoneList,new namecomparator());
		System.out.println(phoneList);
		
	}

}
