package minimumsortarr;

import java.util.Comparator;
public class priceComparator implements Comparator<phone>{

	@Override
	public int compare(phone o1, phone o2) {
		// TODO Auto-generated method stub
		return o1.PhonePrice - o2.PhonePrice;
	}	

	

}
