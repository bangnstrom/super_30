package codes;

public class jdbc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
