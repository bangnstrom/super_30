package codes;

public interface demo {
	void myMethod();
}
