package codes;

import java.util.*;
import java.util.stream.Collectors;

public class streamDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> arList = new ArrayList<>();
		arList.add(15);
		arList.add(1);
		arList.add(44);
		
		List<Integer> newArList = new ArrayList<>();
		newArList = arList.stream().filter(x -> x >= 15).collect(Collectors.toList());
		newArList.stream().forEach(x -> System.out.println(x));
//		List<Integer> arListfromMethod = findElements(arList);
//		for(Integer i: arListfromMethod) {
//			System.out.println(i);
//		}

	}
//	public static List<Integer>findElements(List<Integer>arList){
//		List<Integer> newArList = new ArrayList<>();
//		for(Integer i:arList) {
//			if(i >= 15) {
//				newArList.add(i);			
//				
//			}
//		}
//		return newArList;
//	}

}
