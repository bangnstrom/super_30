package codes;

interface remo{
	void yourMethod();
}
 
//class remoing implements remo{
//
//	@Override
//	public void yourMethod() {
//	// TODO Auto-generated method stub
//		System.out.print("enjoy sunday");
//		
//	}
//	
//}

public class funcInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		remoing r1 = new remoing();
//		r1.yourMethod();
		remo r1 = ()->{System.out.print("lets enjoy sunday");};
		r1.yourMethod();
		
	}

}
