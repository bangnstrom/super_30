package day_threee;

public class sortwithfrequency {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = {2,4,2,3,5,3,4,3,3};
		int[] arr1;		
		for(int i = 0; i<arr.length;i++) {
			System.out.print(arr[i]);
		}
		
	

	}

}
