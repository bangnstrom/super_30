package vehicle;


import java.util.Scanner;

public class sorted_rotated {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner obj = new Scanner(System.in);
		System.out.println("enter the size of array:");
		int sizee = obj.nextInt();
		int[] arr = new int[sizee]; 
		System.out.println("enter the elements of array:");
		
		for(int i =0;i<sizee;i++) {
			arr[i] = obj.nextInt();
		}
		
		for(int i =0;i<sizee;i++) {
			System.out.print(arr[i]);
		}
		
		
		

	}

}
