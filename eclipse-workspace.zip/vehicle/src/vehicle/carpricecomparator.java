package vehicle;

import java.util.Comparator;

public class carpricecomparator implements Comparator<car> {

	@Override
	public int compare(car o1, car o2) {
		// TODO Auto-generated method stub
		return o1.carPrice - o2.carPrice;
	}

}
