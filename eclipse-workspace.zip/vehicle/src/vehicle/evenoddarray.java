package vehicle;

public class evenoddarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = {9,81,76,243,12,0,1,6,32,55};
		
		int index =0;
		
		for(int i =0;i<arr.length;i++) {
			if(arr[i]%2==0) {
				int temp = arr[i];
				arr[i] = arr[index];
				arr[index] = temp;
				index++;
			
			}
		}
		for(int i=0;i<arr.length;i++) {
			
			if(arr[i+1]<arr[i]) {
				int tempe = arr[i];
				arr[i] = arr[i+1];
				arr[i+1] = tempe; 
			}
		}
		for(int j: arr) {
			System.out.print(j+",");
		}
	}

}
