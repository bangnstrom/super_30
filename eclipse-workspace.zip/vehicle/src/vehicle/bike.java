package vehicle;

public class bike implements Comparable<bike>{

	String bikeName;
	int bikePrice;
	
	
	public bike() {
		super();
		// TODO Auto-generated constructor stub
	}


	public bike(String bikeName, int bikePrice) {
		super();
		this.bikeName = bikeName;
		this.bikePrice = bikePrice;
	}


	@Override
	public String toString() {
		return "bike [bikeName=" + bikeName + ", bikePrice=" + bikePrice + "]";
	}


	public String getBikeName() {
		return bikeName;
	}


	public void setBikeName(String bikeName) {
		this.bikeName = bikeName;
	}


	public int getBikePrice() {
		return bikePrice;
	}


	public void setBikePrice(int bikePrice) {
		this.bikePrice = bikePrice;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}


	@Override
	public int compareTo(bike c2) {
		// TODO Auto-generated method stub
		return this.bikePrice -c2.bikePrice;
//		return 0;
	}
	

}
