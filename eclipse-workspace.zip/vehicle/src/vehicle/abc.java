package vehicle;

public class abc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String S= "aaaabbbccca";
		int a =0;
		int b =0;
		int c =0;
		
		for(int i =0;i<S.length();i++) {
			if(S.charAt(i) == 'a') {
				a++;
			}
			else if(S.charAt(i) == 'b') {
				b++;
			} 
			else if(S.charAt(i) == 'c') {
				c++;
			}
			else {
				System.out.print("invaild input");
			}
		}
		
		System.out.print("a"+a+"b"+b+"c"+c);
	}

}
