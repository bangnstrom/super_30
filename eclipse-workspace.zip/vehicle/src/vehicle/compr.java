package vehicle;
import java.util.ArrayList;
import java.util.Collections;


public class compr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<car> cars = new ArrayList<>();
		ArrayList<bike> bikes = new ArrayList<>();
		
		
		
		cars.add(new car("mercedes",4500000));
		cars.add(new car("Audi R8",12000000));
		cars.add(new car("lamborghini",2000000));
		cars.add(new car("koenigseg",1700000));
		cars.add(new car("porsche",1300000));
		
		bikes.add(new bike("bajaj",4500000));
		bikes.add(new bike("kawasaki ninga",12000000));
		bikes.add(new bike("harley davidson",2000000));
		bikes.add(new bike("ktm",1700000));
		bikes.add(new bike("royal enfield",1300000));
		
		

		Collections.sort(bikes);
		System.out.println(bikes);
		System.out.println(cars);
		Collections.sort(cars,new carpricecomparator());
		System.out.println(cars);
		Collections.sort(cars,new carnamecomparator());
		System.out.println(cars);
		
	}

}


