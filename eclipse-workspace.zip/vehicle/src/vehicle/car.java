package vehicle;

public class car implements Comparable<car> {

	String carModel;
	int carPrice;
	
	
	public car() {
		super();
		// TODO Auto-generated constructor stub
	}


	public car(String carModel, int carPrice) {
		super();
		this.carModel = carModel;
		this.carPrice = carPrice;
	}


	@Override
	public String toString() {
		return "car [carModel=" + carModel + ", carPrice=" + carPrice + "]";
	}


	public String getCarModel() {
		return carModel;
	}


	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}


	public int getCarPrice() {
		return carPrice;
	}


	public void setCarPrice(int carPrice) {
		this.carPrice = carPrice;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}


	


	@Override
	public int compareTo(car o) {
		// TODO Auto-generated method stub
		return 0;
	}


}
