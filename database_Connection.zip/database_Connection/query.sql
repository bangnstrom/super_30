CREATE DATABASE IF NOT EXISTS hospital_db;
USE hospital_db;

CREATE TABLE patients (
    patient_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    age INT,
    gender ENUM('Male', 'Female', 'Other'),
    address VARCHAR(255),
    phone VARCHAR(20)
);

CREATE TABLE doctors (
    doctor_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    specialty VARCHAR(100),
    phone VARCHAR(20)
);

CREATE TABLE appointments (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT,
    doctor_id INT,
    appointment_date DATE,
    diagnosis TEXT,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id)
);

INSERT INTO patients (name, age, gender, address, phone) VALUES
('Jane Smith', 28, 'Female', '456 Elm St', '555-5678'),
('Rishabh Rai', 30, 'Male', 'mit_aoe 27', '9805734445');


INSERT INTO doctors (name, specialty, phone) VALUES
('Dr. House', 'Diagnostics', '555-0001'),
('Dr. Grey', 'Surgery', '555-0002');

SELECT * FROM patients;



