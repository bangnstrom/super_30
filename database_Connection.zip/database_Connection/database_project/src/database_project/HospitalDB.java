package database_project;

import java.sql.*;
import java.util.Scanner;

public class HospitalDB {

    private static final String URL = "jdbc:mysql://localhost:3306/hospital_db";
    private static final String USER = "root"; // your MySQL username
    private static final String PASSWORD = "root"; // your MySQL password

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            // Load MySQL Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("✅ Connected to MySQL!");

            while (true) {
                System.out.println("\nHOSPITAL MANAGEMENT SYSTEM");
                System.out.println("1. Add Patient");
                System.out.println("2. View Patients");
                System.out.println("3. View Doctors");
                System.out.println("4. Book Appointment");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");

                int choice;
                try {
                    choice = Integer.parseInt(sc.nextLine());
                } catch (NumberFormatException e) {
                    System.out.println("❌ Invalid input. Please enter a number.");
                    continue;
                }

                switch (choice) {
                    case 1:
                        addPatient(conn, sc);
                        break;
                    case 2:
                        viewPatients(conn);
                        break;
                    case 3:
                        viewDoctors(conn);
                        break;
                    case 4:
                        bookAppointment(conn, sc);
                        break;
                    case 5:
                        System.out.println("👋 Exiting system...");
                        conn.close();
                        sc.close();
                        return;
                    default:
                        System.out.println("❌ Invalid choice. Please try again.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void addPatient(Connection conn, Scanner sc) {
        try {
            System.out.print("Enter patient name: ");
            String name = sc.nextLine();
            System.out.print("Enter patient age: ");
            int age = Integer.parseInt(sc.nextLine());
            System.out.print("Enter patient gender (Male/Female/Other): ");
            String gender = sc.nextLine();
            System.out.print("Enter patient address: ");
            String address = sc.nextLine();
            System.out.print("Enter patient phone: ");
            String phone = sc.nextLine();

            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO patients (name, age, gender, address, phone) VALUES (?, ?, ?, ?, ?)"
            );
            ps.setString(1, name);
            ps.setInt(2, age);
            ps.setString(3, gender);
            ps.setString(4, address);
            ps.setString(5, phone);
            ps.executeUpdate();

            System.out.println("✅ Patient added successfully!");
        } catch (SQLException e) {
            System.out.println("❌ Error adding patient: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("❌ Invalid age format.");
        }
    }

    private static void viewPatients(Connection conn) {
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM patients");

            System.out.println("\n📋 Patients:");
            while (rs.next()) {
                System.out.println("- ID: " + rs.getInt("patient_id") +
                        ", Name: " + rs.getString("name") +
                        ", Age: " + rs.getInt("age") +
                        ", Gender: " + rs.getString("gender") +
                        ", Address: " + rs.getString("address") +
                        ", Phone: " + rs.getString("phone"));
            }
        } catch (SQLException e) {
            System.out.println("❌ Error viewing patients: " + e.getMessage());
        }
    }

    private static void viewDoctors(Connection conn) {
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM doctors");

            System.out.println("\n👨‍⚕️ Doctors:");
            while (rs.next()) {
                System.out.println("- ID: " + rs.getInt("doctor_id") +
                        ", Name: " + rs.getString("name") +
                        ", Specialty: " + rs.getString("specialty") +
                        ", Phone: " + rs.getString("phone"));
            }
        } catch (SQLException e) {
            System.out.println("❌ Error viewing doctors: " + e.getMessage());
        }
    }

    private static void bookAppointment(Connection conn, Scanner sc) {
        try {
            // Display patients for selection
            viewPatients(conn);
            System.out.print("Enter patient ID: ");
            int patientId = Integer.parseInt(sc.nextLine());

            // Display doctors for selection
            viewDoctors(conn);
            System.out.print("Enter doctor ID: ");
            int doctorId = Integer.parseInt(sc.nextLine());

            System.out.print("Enter appointment date (YYYY-MM-DD): ");
            String date = sc.nextLine();
            System.out.print("Enter diagnosis: ");
            String diagnosis = sc.nextLine();

            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO appointments (patient_id, doctor_id, appointment_date, diagnosis) VALUES (?, ?, ?, ?)"
            );
            ps.setInt(1, patientId);
            ps.setInt(2, doctorId);
            ps.setDate(3, Date.valueOf(date));
            ps.setString(4, diagnosis);
            ps.executeUpdate();

            System.out.println("✅ Appointment booked successfully!");
        } catch (SQLException e) {
            System.out.println("❌ Error booking appointment: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("❌ Invalid ID format.");
        } catch (IllegalArgumentException e) {
            System.out.println("❌ Invalid date format. Use YYYY-MM-DD.");
        }
    }
}