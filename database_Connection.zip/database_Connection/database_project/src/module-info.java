/**
 * 
 */
/**
 * 
 */
module database_project {
	requires java.sql;
}