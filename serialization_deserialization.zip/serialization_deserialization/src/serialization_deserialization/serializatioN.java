package serialization_deserialization;
import java.io.*;
public class serializatioN {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		student s1 = new student(1,"Ayush");
		FileOutputStream fos = new FileOutputStream("C:\\student\\kuchbhi.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(s1);
		oos.close();
		fos.close();
		System.out.println("done with the serilzation..");
	}

}
