package serialization_deserialization;
import java.io.*;


public class deserializatioN {

	public static void main(String[] args)  throws Exception {
		// TODO Auto-generated method stub
		FileInputStream fis = new FileInputStream("C:\\student\\kuchbhi.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		student s1 = (student) ois.readObject();
		ois.close();
		fis.close();
		System.out.println("Object has been deserialized");
		System.out.println("Id: "+s1.id+",Name: "+s1.name);
	}

}
